﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using _3A1_AndreClauver_2.Code.BLL;
using _3A1_AndreClauver_2.Code.DTO;

namespace _3A1_AndreClauver_2.UI
{
    public partial class FrmSupermercado : Form
    {

        SupermercadoBLL medbll = new SupermercadoBLL();
        SupermercadoDTO meddto = new SupermercadoDTO();

        public FrmSupermercado()
        {
            InitializeComponent();
        }

        private void FrmSupermercado_Load(object sender, EventArgs e)
        {
            dvg_Supermercado.DataSource = medbll.Listar();
        }

        private void btn_Cadastrar_Click(object sender, EventArgs e)
        {
            meddto.Produto = txt_Produto.Text;
            meddto.Preco = txt_Preco.Text;

            medbll.Inserir(meddto);

            MessageBox.Show("Cadastrado com sucesso!", "Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txt_ID.Clear();
            txt_Produto.Clear();
            txt_Preco.Clear();
        }

        private void btn_Editar_Click(object sender, EventArgs e)
        {
            meddto.Id = int.Parse(txt_ID.Text);
            meddto.Produto = txt_Produto.Text;
            meddto.Preco = txt_Preco.Text;

            //Envio do dto preenchido para o método editar
            medbll.Editar(meddto);

            MessageBox.Show("Alterado com sucesso!", "Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);

            medbll.Listar();

            txt_ID.Clear();
            txt_Produto.Clear();
            txt_Preco.Clear();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            meddto.Id = int.Parse(txt_ID.Text);

            //Envio do dto preenchido para o método editar
            medbll.Excluir(meddto);

            //Mensagem de sucesso
            MessageBox.Show("Excluido com sucesso!", "Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Atualização do GridView
            medbll.Listar();

            //Limpeza dos componentes
            txt_ID.Clear();
            txt_Produto.Clear();
            txt_Preco.Clear();
        }

        private void dvg_Supermercado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_ID.Text = dvg_Supermercado.Rows[e.RowIndex].Cells[0].Value.ToString();
            txt_Produto.Text = dvg_Supermercado.Rows[e.RowIndex].Cells[1].Value.ToString();
            txt_Preco.Text = dvg_Supermercado.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
    }
}
