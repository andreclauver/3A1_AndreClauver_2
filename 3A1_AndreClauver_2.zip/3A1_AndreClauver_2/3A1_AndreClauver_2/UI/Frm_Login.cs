﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using _3A1_AndreClauver_2.Code.BLL;
using _3A1_AndreClauver_2.Code.DTO;

namespace _3A1_AndreClauver_2.UI
{
    public partial class Frm_Login : Form
    {

        LoginBLL loginBBL = new LoginBLL();
        LoginDTO loginDTO = new LoginDTO();

        public Frm_Login()
        {
            InitializeComponent();
        }

        private void Frm_Login_Load(object sender, EventArgs e)
        {

        }

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            loginDTO.Email = txt_email.Text;
            loginDTO.Senha = txt_senha.Text;


            //Chamada do método para verificar o acesso: 
            if (loginBBL.RealizarLogin(loginDTO) == true)
            {

                FrmSupermercado frm_supermercado = new FrmSupermercado();
                frm_supermercado.ShowDialog();
            }
            else
            {
                //Mensagem de sucesso
                MessageBox.Show("Verifique e-mail e senha.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
