﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using _3A1_AndreClauver_2.Code.DTO;
using _3A1_AndreClauver_2.Code.DAL;
using System.Data;

namespace _3A1_AndreClauver_2.Code.BLL
{
    class SupermercadoBLL
    {
        AcessoBancoDados conexao = new AcessoBancoDados();
        string tabela = "supermercado";


        
        public void Inserir(SupermercadoDTO medDto)
        {
            string inserir = $"insert into {tabela} values(null,'{medDto.Produto}','{medDto.Preco}')";
            conexao.ExecutarComando(inserir);
        }

        public DataTable Listar()     
        {
            string sql = $"select * from {tabela} order by id;";
            return conexao.ExecutarConsulta(sql);
        }

        public void Editar(SupermercadoDTO medDto)
        {
            string alterar = $"update {tabela} set prduto = '{medDto.Produto}', preco = '{medDto.Preco}' where id = '{medDto.Id}';";
            conexao.ExecutarComando(alterar);
        }


        public void Excluir(SupermercadoDTO medDto)
        {
            string excluir = $"delete from {tabela} where id = '{medDto.Id}';";
            conexao.ExecutarComando(excluir);
        }
    }
}
