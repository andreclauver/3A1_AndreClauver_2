CREATE TABLE tbl_comprador
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nomeComprador VARCHAR(40),
    idProduto INT NOT NULL,
    FOREIGN KEY(idProduto) REFERENCES tbl_produto(id)
);

CREATE TABLE tbl_login
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(40),
    senha INT NOT NULL
);