CREATE DATABASE supermercado;
USE supermercado;

CREATE TABLE supermercado
(
   id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   produto VARCHAR(40) NOT NULL
   preco VARCHAR(30) NOT NULL
);

CREATE TABLE tbl_Preco
(
   codigo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   valor VARCHAR(40) NOT NULL
   FOREGIN KEY(idsupermercado) REFERENCES supermercado(id)
);   